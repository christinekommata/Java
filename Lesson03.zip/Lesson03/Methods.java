class Methods
{
	static int add(int a, int b)
	{
		int c = 0; 	// step 1
		c = a+b;	// step 2
		return c;	// step 3
	}

	public static void main(String args[])
	{
		// Methods m = new Methods(); // this is not needed when add is static
		// int x = Methods.add(5,2);  // this is not needed because main is defined within class Methods
		
		int x = add(5,2);
		System.out.println(x);
	}

}
