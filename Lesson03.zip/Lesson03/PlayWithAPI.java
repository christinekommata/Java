class PlayWithAPI
{
	public static void main(String args[])
	{
		String s = "Hello World";
		// String s = new String();

		for (int i = 0; i < s.length(); i++)
		{		
			System.out.println(s.charAt(i));
		}

		double x = 4.0;
		System.out.println("The cosine of " + x + " is " + Math.cos(x));
		
	}
}