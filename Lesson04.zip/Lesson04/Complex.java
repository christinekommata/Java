class Complex
{
	// z = a+bi, with a,b belong to R
	double a, b;
	
	// Constructor
	Complex(double a, double b)
	{
		this.a = a;
		this.b = b;
	}

	Complex()
	{
		this(0.0, 0.0);
	}

	public String toString()
	{
		String s = a + "+" + b + "i";
		return s;

		// Alternatively we could write this
		// return (a + "+" + b + "i"); 
	}

	// Not recommended
	// String add(double a1, double b1, double a2, double b2)


	// Adds two complex numbers --------------------------------------
	static Complex add(Complex z1, Complex z2)
	{
		Complex result = new Complex();
		result.a = z1.a + z2.a;
		result.b = z1.b + z2.b;
		return result;
	}
	// ---------------------------------------------------------------

	// z = z + other
	void add(Complex other)
	{
		a = a + other.a;
		b = b + other.b;
	}

	// Equals to compare Complex numbers
	public boolean equals(Complex other)
	{
		boolean boo = false;
		if ( (a == other.a) && (b == other.b) ) boo = true;
		return boo; 
	}

	public static void main(String args[])
	{
		Complex z1 = new Complex(5,2); // z1=5+2i
		System.out.println(z1); // I am allowed to write this because Complex has toString

		Complex z2 = new Complex(2,3);
		System.out.println(z2);


		// Example 1
		// Complex z = new Complex(); // not needed because the object is allocated witing add!
		Complex z3 = add(z1,z2);
		System.out.println("z1+z2 = " + z3);

		// Example 2
		Complex z4 = new Complex(1,2);
		z4.add(z2);

		System.out.println("z4+z2 = " + z4);

		// Comparisons between objects

		// Example comparison of Strings
		String s1 = new String("one");
		String s2 = new String("one");
		System.out.println("Is s1 equal to s2? " + (s1==s2)); // compares if the two objects are the same
		System.out.println("Is s1 equal to s2? " + (s1.equals(s2))); // compares if the two objects have the same content

		// Example comparison of Complex
		System.out.println("Is z1 equal to z2? " + (z1.equals(z2)));		
				
	}
}