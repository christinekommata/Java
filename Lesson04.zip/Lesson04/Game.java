// Example of how to import a package (library)
import java.lang.*; // not needed because java.lang is automatically imported
import java.util.*; // needed if we want to use a class from java.util package

class Game
{
	public static void main(String args[])
	{
		Human m = new Human(); // m is an object of class Human (or m is an instance of Human)

		System.out.println(m.name);
		m.name = "Mary";
		m.height = 10;

		Human j = new Human();
		j.name = "John";
		j.height = 7;

		Ufo r = new Ufo();
		r.color = "red";
		r.diameter = 50;

		Ufo b; // declare variable b as of type Ufo
		b = new Ufo(); // construct a new object to hold an Ufo

		// ----------------------------------------------------

		// Objects can perform actions

		m.shoot(30); // 30 is an argument of shoot
		j.shoot(50);

		// Play with static
		System.out.println(m.numberOfEyes);
		System.out.println(j.numberOfEyes);
		m.numberOfEyes = 1; 

		System.out.println(m.numberOfEyes);
		System.out.println(j.numberOfEyes);

		Human.numberOfEyes = 3; 
		System.out.println(m.numberOfEyes);
		System.out.println(j.numberOfEyes);

		Human h = new Human("Kostas", 32);
		
		Human n = null;
		n = new Human("Nikos", 20);
		System.out.println(n.name);

		System.out.println(n.toString());

		System.out.println(m); // this is equivalent to m.toString()
				
		m.shoot(60);
		m.shoot();

		// Call static method
		Human.sayHello();

	}
}