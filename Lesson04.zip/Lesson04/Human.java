class Human
{
	// Human extended to explain static methods

	// Properties
	String name; // Instance variables
	int height; 
	static int numberOfEyes = 2; // the same value for all objects of this class

	Human() // No-argument constructor
	{
		name = "noname";
		// This is equivalent to name = new String("noname");

		height = 1;
	}

	Human(String name, int height) // constructor
	{
		this.name = name;  	// we use this.name to indicate the instance variable name
		this.height = height;
	}

	Human(String n)
	{
		this(n,0); // calls the above constructor
	}

	void shoot(int angle) // angle is a parameter
	{	
		System.out.println("I am " + name + " and I shoot by " + angle + " degrees");
	}

	void shoot()
	{
		this.shoot(20);
	}

	// This method is independent from instance variables
	static void sayHello()
	{
		System.out.println("Hello");
	}

	public String toString()
	{
		String ss = name + "," + height;
		return ss;	
	}

	// Add main for testing purposes
	public static void main(String args[])
	{
		Human x = new Human("Mitsos", 20);
		System.out.println(numberOfEyes); // instead of writing Human.numberOfEyes
		

	}

}