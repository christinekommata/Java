import java.util.Scanner;

class SomeAPIClasses
{
	public static void main(String args[])
	{
		String s1 = "test";
		String s2 = new String("test");
		
		// Wrapper classes in java.lang package
		// int
		Integer i1 = new Integer(5);
		// Conversion from String to int
		int i2 = Integer.parseInt("6");
		System.out.println(i2);

		Integer i3 = 5; // boxing
		int i4 = i3; // unboxing

		// Other similar classes: Double, Float, Character, Boolean ...

		// Example keyboard input
		Scanner scan = new Scanner(System.in);
		int a = 0, b = 0;
		System.out.print("Give a = ");
		a = scan.nextInt();
		System.out.print("Give b = ");
		b = scan.nextInt();
		System.out.println("a+b="+(a+b));

	}
}