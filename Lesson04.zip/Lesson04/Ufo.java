class Ufo
{
	String color;
	int diameter;
}