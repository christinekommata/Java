public class Add
{
	public static void main(String[] args)
	{

		if ( (args.length == 1) && (args[0].equals("h") ) )
		{
			System.out.println("Usage: Add number1 number2 ...");
			System.out.println("Returns the summation of all numbers.");
			return;
		}

		double sum = 0.0;
		for (int i = 0; i < args.length; i++)
		{
			sum += Double.parseDouble(args[i]);
		}
		System.out.println("The sum equals " + sum);
	}
}
