import java.util.Random;

public class Arrays
{

	// A method that returns the sum of d array elements
	public static double add(double[] d)
	{
		double sum = 0.0;
		for (int i = 0; i < d.length; i++)
		{
			sum += d[i];	
		}
		return sum;
	}

	// A method that returns an array of random numbers
	public static int[] randomNumbers(int howMany)
	{
		int[] a = new int[howMany];
		
		Random r = new Random();
		for (int i = 0; i < a.length; i++)
		{
			a[i] = r.nextInt(50); // up to 50
		}
		return a;
	}	

	public static void main(String args[])
	{
		// 1D ARRAYS -----------------------------------------

		// In C
		/*
		int a[10]; // static array allocation
		int *a = (int *)malloc(10*sizeof(int)); // dynamic array allocation
		free(a); // deallocate
		*/

		// In Java
		// int a[];
		int[] a;
		a = new int[10];

		int[] b = new int[10];

		a = new int[5]; // the previous object is thrown to the garbage collector
		a[0] = 1;
		a[1] = 10;
		
		System.out.println("The length of a is " + a.length); // .length returns the array size

		for (int i = 0; i < a.length; i++)
		{
			System.out.println(a[i]);
		} 

		// Math Summation
		double[] d = {4.2, 3.6, 7.8};
		double sum = 0.0;
		for (int i = 0; i < d.length; i++)
		{
			sum = sum + d[i];
		} 
		System.out.println("The sum of d elements is " + sum);		


		// 2D ARRAYS -----------------------------------------
		/* Example (in math):
				aa =	|1 2 3|
					|4 5 6|
					|7 8 9|			
		*/

		// A 2D array is a 1D array of 1D arrays
		int[][] aa = { 	{1, 2, 3}, 
				{4, 5, 6}, 
				{7, 8, 9}  };

		int[][] bb = new int[3][2]; // 3 rows, 2 columns
		bb[0][0] = 10;
		bb[0][1] = 5;		

		// Number of rows bb.length
		// Number of columns bb[0].length or bb[1].length ...

		for (int i = 0; i < bb.length; i++)
		{
			for (int j = 0; j < bb[i].length; j++)
			{
				System.out.print(bb[i][j]+"\t");
			}
			System.out.println();
		}

		// RAGGED ARRAYS

		int[][] cc = { 	{1, 2, 3},
				{4, 5, 6, 7, 8} };

		// Lets do the same using new
		int[][] dd = new int[2][];
		dd[0] = new int[3];
		dd[1] = new int[5];

		dd[0][0] = 1;
		dd[0][1] = 2;
		//..
		// but dd[0][3] and dd[0][4] do not exist !!!

		// Copy cc to dd
		System.out.println("Our ragged array:");
		for (int i = 0; i < dd.length; i++)
		{
			for (int j = 0; j < dd[i].length; j++)
			{
				dd[i][j] = cc[i][j];
				System.out.print(dd[i][j] + "\t");
			}
			System.out.println();
		}

		// ARRAYS OF OBJECTS
		System.out.println("Our dates array:");

		Date[] dates = new Date[10];
		dates[0] = new Date(13, 3, 2019);
		dates[1] = new Date(1, 1, 2000);
		// ..
		for (int i = 0; i < dates.length; i++)
		{
			System.out.println(dates[i]);
		}		

		// In 2D
		Date[][] dates2D = new Date[2][3];
		dates2D[0][0] = new Date(4, 5, 2019);
		// ..

		// In 2D ragged
		Date[][] dates2DR = new Date[2][];
		dates2DR[0] = new Date[3]; // create the first row
		dates2DR[1] = new Date[5]; // create the second row

		dates2DR[0][0] = new Date(1, 3, 2015);
		// ..

		// ARRAY METHODS
		double[] test = {5.4, 6.2, 7.8}; 
		double summation = add(test);	
		System.out.println("The sum is " + summation);

		System.out.println("The random numbers are: ");
		int[] rands = randomNumbers(10);
		for (int i = 0; i < rands.length; i++)
		{
			System.out.println(rands[i]);
		} 
		
	}
}