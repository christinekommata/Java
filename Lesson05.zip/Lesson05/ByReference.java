public class ByReference
{
	// All primitive types are passed by value
	public static void byValue(int x)
	{
		System.out.println("In method you passed: " + x);
		x = 10;	
		System.out.println("In method x is changed to: " + x);
	
	}

	// All objects are passed by Reference
	public static void byReference(int[] d) // d is an object!
	{
		for (int i = 0; i < d.length; i++)
		{
			d[i] = 1;
		}			
	}


	public static void main(String[] args)
	{
		int x = 5;

		byValue(x);
		System.out.println("In main x remains: " + x);

		int[] y = {5,6,7,8};

		System.out.println("Before calling byReference");
		for (int i = 0; i < y.length; i++)
		{
			System.out.println(y[i]);
		}
		System.out.println("After calling byReference");
		byReference(y);
		for (int i = 0; i < y.length; i++)
		{
			System.out.println(y[i]);
		}

	}
}
