class CallDate
{
	public static void main(String args[])
	{
		Date d1 = new Date(10,12,2018);
		System.out.println(d1);

		// d1.day = -345; // this cannot be done from this class because day is private 
		d1.setDay(25);
		System.out.println(d1);
		System.out.println(d1.getDay());
		
	}
}