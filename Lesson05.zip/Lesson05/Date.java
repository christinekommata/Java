public class Date
{
	private int day, month, year;

	public Date(int d, int m, int y)
	{
		setDate(d,m,y);	
	}

	public Date()
	{
		this(1,1,1900);
	}

	// Mutator methods
	public void setDay(int d)
	{
		if ( (d > 0) && (d <= 31) ) day = d;
	}

	public void setMonth(int m)
	{
		if ( (m > 0) && (m <= 12) ) month = m;
	}

	public void setYear(int y)
	{
		if ( y > 0 ) year = y;
	}

	public void setDate(int d, int m, int y)
	{
		setDay(d);
		setMonth(m);
		setYear(y);
	}

	// Accessor methods
	public int getDay()
	{
		return day;
	}

	public int getMonth()
	{
		return month;
	}

	public int getYear()
	{
		return year;
	}

	public boolean equals(Date other)
	{
		boolean b = false;
		if ( 	(day == other.day) && 
			(month == other.month) && 
			(year == other.year) ) b = true;
		return b;
	}

	public String toString()
	{
		return day + "/" + month + "/" + year;
	}
	
	public static void main(String args[])
	{
		Date d1 = new Date(10,12,2018);
		System.out.println(d1);
	}

}