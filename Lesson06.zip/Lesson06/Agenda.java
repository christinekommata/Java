import java.util.Random;

public class Agenda
{
	Record[] carne;
	int current = 0; // shows the current entry

	public Agenda(int entries)
	{
		carne = new Record[entries];
		for (int i = 0; i < entries; i++)
		{
			carne[i] = new Record();
		}
	}

	// Register a record
	public void setEntry(int day, int month, int year, String note)
	{
		if ( (carne[current].note == null) && (current < carne.length-1) )
		{
			System.out.println(current);
			carne[current] = new Record(day, month, year, note);
			current ++;
		}
	}

	public String toString()
	{
		String s = "";
		for (int i = 0; i < carne.length; i++)
		{
			s += carne[i].toString() + "\n";			
		}		
		return s;
	}

	public static void main(String[] args)
	{
		Agenda myAgenda = new Agenda(10);
		System.out.println(myAgenda);

		myAgenda.setEntry(2,3,2019,"Go for a walk");
		myAgenda.setEntry(25,3,2019,"Go to the parade");
		System.out.println(myAgenda);

		// Massive test
		Random r = new Random();
		for (int i = 0; i < 50; i++)
		{
			myAgenda.setEntry(r.nextInt(30),r.nextInt(12),2019, "Go " + r.nextInt(1000) );	
		}

		System.out.println(myAgenda);

		
		
	}

}