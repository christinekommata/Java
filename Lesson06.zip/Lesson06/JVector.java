// A class representing a vector 
// Dianysma e.g., v = (1, 2, 3)

public class JVector
{
	private int[] vector; // better not to have = new int[3]; because it will be useless

	public JVector(int length)
	{
		vector = new int[length];
	}

	public JVector(int[] other)
	{
		setVector(other);
	}

	public JVector(JVector other) // copy contructor
	{
		// Shallow copy (not recommended)
		// vector = other;

		// Deep copy (recommended)
		vector = new int[other.dimension()];
		for (int i = 0; i < other.dimension(); i++)
		{
			vector[i] = other.vector[i];
		} 
	}

	public int dimension()
	{
		return vector.length;
	}

	public String toString()
	{
		String s = "(";
		for (int i = 0; i < vector.length; i++)
		{
			s += vector[i];
			if (i != vector.length-1) s += ",";
		}
		s += ")";
		return s;
	}

	public void setCoordinate(int position, int value)
	{
		if ( (position >= 0) && (position < dimension()) )
		{
			vector[position] = value;
		}
	}

	public void setVector(int[] other)
	{
	/*
		// Recommended (copies only the elements of other)
		if (other.length == vector.length)
		{
			for (int i = 0; i < other.length; i++)
			{
				vector[i] = other[i];
			}
		} 
	*/
		// Not recommended (makes a shallow copy of other to vector)
		vector = other; // destroys vector and vector becomes a mirror of other
	}

	public int getCoordinate(int position)
	{
		return vector[position];
	}	

	public static void main(String[] args)
	{
		/* Without constructor(not recommended) 
		JVector a = new JVector();
		a.vector[0] = 10;
		a.vector[1] = 20;
		a.vector[2] = 30;

		// I could do that: a.vector = new int[10];

		System.out.println(a);
		*/

		// Example with constructor (recommended)
		JVector a = new JVector(5);
		//a.vector[0] = 40;
		a.setCoordinate(0,40);
		System.out.println(a);

		a = new JVector(3);
		int[] v = {5,6,7};
		a.setVector(v);
		System.out.println(a);
		v[1] = 0; // changing v causes a change in a when the shallow copy method is used
		System.out.println(a);

		// Usage of copy constructor
		JVector c = new JVector(a); // i.e. copy a to c
		System.out.println(c);

	}
}