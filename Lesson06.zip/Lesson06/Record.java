public class Record
{
	Date date;
	String note; 

	public Record(int day, int month, int year, String note)
	{
		date = new Date(day, month, year);
		this.note = note;
	}

	public Record()
	{
		date = new Date();
		note = null;
	}

	public String toString()
	{
		return date.toString() + ": " + note;
	}
}