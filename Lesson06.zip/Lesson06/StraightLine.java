public class StraightLine
{
	Point a, b;
}