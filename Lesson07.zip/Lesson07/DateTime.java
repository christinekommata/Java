// DateTime is a child (subclass) of Date
// DateTime is a Date with additional features

public class DateTime extends Date
{ 
	int hour, minutes, seconds;

	public DateTime(int d, int mo, int y, int h, int mi, int s)
	{
		super(d,mo,y);	// calls the constructor of the superclass Date	
		hour = h;
		minutes = mi;
		seconds = s;
	}

	// Overrides toString of Date
	public String toString()
	{
		return super.toString() + ": " + hour + ":" + minutes + ":" + seconds;
	}

	public static void main(String[] args)
	{
		DateTime dt = new DateTime(3,2,2019,4,5,20);
		System.out.println(dt);
	}
}