// Color image
public class Image 
{
	Pixel[][] p;

	public Image(int rows, int columns)
	{
		if ((rows > 0) && (columns > 0))
		{
			p = new Pixel[rows][columns];
			for (int i = 0; i < rows; i++)
			{
				for (int j = 0; j < columns; j++)
				{
					p[i][j] = new Pixel(0,0,0);
				}
			}
		}
	}		

	public int getRows()
	{
		return p.length;
	}

	public int getColumns()
	{
		return p[0].length;
	}

	public String toString()
	{
		String s = "";
		for (int i = 0; i < getRows(); i++)
		{
			for (int j = 0; j < getColumns(); j++)
			{
				s += p[i][j].toString() + "\t";	
			}
			s += "\n";
		}
		return s;
	}

	public void setPixel(int row, int column, int red, int green, int blue)
	{
		if ( 	(row >= 0) &&
			(row < getRows()) &&
			(column >=0) &&
			(column < getColumns() ) )
		{
			p[row][column].setRGB(red, green, blue);
		}		
	}

	public static void main(String[] args)
	{
		Image myImage = new Image(5,5);
		System.out.println(myImage);

		myImage.setPixel(1,2,255,0,0);
		System.out.println(myImage);
	}
}