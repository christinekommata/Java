public class Pixel
{
	private int r, g, b;

	public Pixel(int r, int g, int b)
	{
		setRGB(r, g, b);
	}

	public void setRGB(int r, int g, int b)
	{
		if ( (r >= 0) && (r <= 255) && (g >= 0) && (g <= 255) && (b >= 0) && (b <= 255))
		{
			this.r = r;
			this.g = g;
			this.b = b;
		}
	}

	public int getR()
	{
		return r;
	}
	
	public int getG()
	{
		return g;
	}

	public int getB()
	{
		return b;
	}

	public int[] getRGB()
	{
		int [] rgb = new int[3];
		rgb[0] = r;
		rgb[1] = g;
		rgb[2] = b;
		return rgb;
	}	

	public String toString()
	{
		return "(" + r + "," + g + "," + b + ")";
	}

	public boolean equals(Pixel other)
	{
		boolean bb = false;
		if ( (r == other.r) && (g == other.g) && (b == other.b) ) bb = true;
		return bb;
	}		

	public static void main(String[] args)
	{	
		Pixel p = new Pixel(255,0,0);
		System.out.println(p);
		p.setRGB(0,255,0);
		System.out.println(p);	
		int[] a = p.getRGB();
		for (int i = 0; i < a.length; i++)
		{
			System.out.println(a[i]);
		}
		
	}

}