import animals.earth.Cat;

public class UsePackage
{
	public static void main(String[] args)
	{
		Cat psipsinel = new Cat();
		psipsinel.speak();
	}
}