package animals.earth; // corresponds to the folder

public class Cat
{
	public String name;

	public void speak()
	{
		System.out.println("niaou");	
	}
}