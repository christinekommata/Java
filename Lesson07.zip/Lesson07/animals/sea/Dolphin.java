package animals.sea; // corresponds to the folder

public class Dolphin
{
	public String name;

	public void speak()
	{
		System.out.println("squick");	
	}
}