public abstract class Animal
{
	String name;

	public void walk(int numberOfSteps)
	{
		System.out.println("I walked " + numberOfSteps + " steps");
	}

	public abstract void speak();
}