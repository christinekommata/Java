public class BankAccount
{
	private Money[] transaction;
	private int current;

	public BankAccount(int maxTransactions)
	{
		transaction = new Money[maxTransactions];
	}

	public void deposit(long e, long c)
	{
		transaction[current] = new Money(e, c);
		current++;	
	}

	public String toString()
	{
		String s = "";
		for (int i = 0; i < current; i++)
		{
			s += transaction[i].toString() + "\n";
		}
		return s;
	}
	
	// Inner class
	private class Money
	{
		long euro, cents;

		public Money(long e, long c)
		{
			euro = e;
			cents = c;
		}

		public String toString()
		{
			return euro + " euro, " + cents + " cents";
		}
	}

	public static void main(String[] args)
	{
		BankAccount x = new BankAccount(5);
		x.deposit(5,10);
		x.deposit(10,0);
		System.out.println(x);
	}
}