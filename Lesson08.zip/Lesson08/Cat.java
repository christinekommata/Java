public class Cat extends Animal
{
	public void speak()
	{
		System.out.println("niaou");
	}
}