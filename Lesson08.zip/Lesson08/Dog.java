public class Dog extends Animal implements Wild
{
	public void speak()
	{
		System.out.println("arf");
	}

	public void bites()
	{
		System.out.println("I bite you");
	}
}