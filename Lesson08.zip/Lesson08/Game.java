public class Game
{
	public static void main(String[] args)
	{
		Animal a;
		// Animal b = new Animal(); // Not allowed to construct objects of abstract classes

		Cat psipsinel = new Cat();
		Dog azor = new Dog();

		psipsinel.speak();
		azor.speak();

		// Late or dynamic binding
		a = psipsinel;
		a.speak();

		a = azor;
		a.speak();

		azor.bites();

		// Upcasting and downcasting -------
		// Remember simple casting?
		int x = 0;
		double y = 1000.12343434234;
		x = (int)y; // casting 
		y = (double)x; 

		// Upcasting and downcasting refers to classes
		a = (Animal)psipsinel;	
		psipsinel = (Cat)a;
		
	}
}