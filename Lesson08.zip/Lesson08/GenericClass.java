public class GenericClass<T>
{
	T x;

	public String toString()
	{
		return "The value of x is " + x;
	}
	
}