import java.util.ArrayList;

public class PlayWithArrayLists
{
	public static void main(String[] args)
	{
		ArrayList<String> list1 = new ArrayList<String>();
		list1.add("John");
		list1.add("Mary");
		list1.add("Costas");
		list1.add("Anna");

		list1.remove("Costas");

		// Classic for loop
		for (int i = 0; i < list1.size(); i++)
		{
			System.out.println(list1.get(i));
		}

		// Modern for loop
		for (String element:list1)
		{
			System.out.println(element);
		}
	}
}