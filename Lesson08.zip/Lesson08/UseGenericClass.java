public class UseGenericClass
{
	public static void main(String[] args)
	{
		GenericClass<String> a = new GenericClass<String>();
		a.x = "Hello";
		System.out.println("Called for String: " + a);

		// This is for integers (we cannot use primitive types like int)
		GenericClass<Integer> b = new GenericClass<Integer>();
		b.x = 5;
		System.out.println("Called for int: " + b);
	
	}
}