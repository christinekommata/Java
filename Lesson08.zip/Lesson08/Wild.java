// All methods in an interface are abstract
public interface Wild
{
	public void bites();
}